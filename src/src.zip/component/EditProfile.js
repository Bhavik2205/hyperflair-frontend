import React, {useEffect} from "react";

import ImageUploading from "react-images-uploading";

const EditProfile = () => {
	useEffect(() => {
        window.scrollTo(0, 0)
    }, []);
	
	const [images, setImages] = React.useState([]);
	const [cover, setCover] = React.useState([]);

	const onChange = (imageList, addUpdateIndex) => {
		setImages(imageList);
	};

	const onChangeCover = (imageList, addUpdateIndex) => {
		setCover(imageList);
	};


	return (
		<>
			<div className="container">
				<div className="row row--grid">
					<div className="col-12 col-xl-12">
						<div className="main__title main__title--page mb-4">
							<h1>Edit profile</h1>
							<p className="mt-0 text-gray">You can set preferred display name, create your branded profile URL and manage other personal settings</p>
						</div>
					</div>
					<div className="col-12 col-xl-3">
						<div className="author author--page">
							<div className="author__meta">
								<ul className="nav flex-column nav-pills nav-fill w-100">
									<li className="nav-item">
										<a className="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Edit Profile Image</a>
									</li>
									<li className="nav-item">
										<a className="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Personal Information</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div className="col-12 col-xl-9">
						<div className="tab-content" id="v-pills-tabContent">
							<div className="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
								<div className="author__meta">
									<div className="row">
										<div className="col-sm-12 col-md-6 col-lg-5">
											<h4 className="mb-3">Change Profile Picture</h4>
											<div className="profile-img">
												<ImageUploading value={images} onChange={onChange} dataURLKey="data_url" name="image">
													{({
														imageList,
														onImageUpload,
														isDragging,
														dragProps
													}) => (
														<div className="upload__image-wrapper">
															<div style={isDragging ? { color: "red" } : null} onClick={onImageUpload}{...dragProps} className="img-wrapper">
																Click or Drop here
																{imageList.map((image, index) => (
																	<div key={index} className="image-item">
																		<img src={image.data_url} alt="" />
																	</div>
																))}
																<button className="edit-profile-pic"><i className="fa-solid fa-pencil"></i></button>
															</div>
														</div>
													)}
												</ImageUploading>
											</div>
										</div>
										<div className="col-sm-12 col-md-6 col-lg-7">
											<h4 className="mb-3">Change Cover Picture</h4>
											<div className="profile-img">
												<ImageUploading value={cover} onChange={onChangeCover} dataURLKey="data_url" name="cover">
													{({
														imageList,
														onImageUpload,
														isDragging,
														dragProps
													}) => (
														<div className="upload__image-wrapper">
															<div style={isDragging ? { color: "red" } : null} onClick={onImageUpload}{...dragProps} className="img-wrapper">
																Click or Drop here
																{imageList.map((image, index) => (
																	<div key={index} className="image-item">
																		<img src={image.data_url} alt="" />
																	</div>
																))}
																<button className="edit-profile-pic"><i className="fa-solid fa-pencil"></i></button>
															</div>

														</div>
													)}
												</ImageUploading>
											</div>
										</div>
										<div className="col-sm-12 col-md-12 col-lg-12 mt-3">
											<button className="btn-primary">Update</button>
										</div>
									</div>
								</div>
							</div>
							<div className="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
								<div className="author__meta">
									<form className="sign__form sign__form--profile mt-0">
										<div className="sign__group">
											<label className="sign__label" htmlFor="username">Display name</label>
											<input id="username" type="text" name="username" className="sign__input" placeholder="Enter your display name" />
										</div>
										<div className='sign__group'>
											<label className="sign__label required-field" htmlFor="short-bio">Short Bio</label>
											<textarea id="short-bio" name="short-bio" className="sign__textarea" placeholder="Tell about yourself in a few words"></textarea>
										</div>
										<div className="sign__group">
											<label className="sign__label" htmlFor="email">Email Address</label>
											<input id="email" type="text" name="email" className="sign__input" placeholder="Enter your email" />
										</div>
										<h4 className="sign__title mb-2">Social Connections</h4>
										<p className="f-12 f-500 mb-3">Help collectors verify your account by connecting Social Connections</p>
										<div className="sign__group">
											<label className="sign__label" htmlFor="twitter">Twitter Link</label>
											<input id="twitter" type="text" name="twitter" className="sign__input" placeholder="Enter your Twitter Link" />
										</div>
										<div className="sign__group">
											<label className="sign__label" htmlFor="instagram">Instagram Link</label>
											<input id="instagram" type="text" name="instagram" className="sign__input" placeholder="Enter your Instagram Link" />
										</div>
										<div className="sign__group">
											<label className="sign__label" htmlFor="sitelink">Personal site or portfolio</label>
											<input id="sitelink" type="text" name="sitelink" className="sign__input" placeholder="https://yoursitelink.com" />
										</div>
										<button className="btn-primary">Submit</button>
									</form>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</>
	)
}
export default EditProfile