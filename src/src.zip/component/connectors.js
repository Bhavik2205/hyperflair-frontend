import { InjectedConnector } from "@web3-react/injected-connector";
import { WalletConnectConnector } from "@web3-react/walletconnect-connector";
import { BscConnector } from "@binance-chain/bsc-connector";
import { rpc_url } from "./constants";

const supported_chain_id = Object.keys(rpc_url).map((key, item) => {
  return parseInt(key);
});

const POLLING_INTERVAL = 12000;

export const injected = new InjectedConnector({
  supportedChainIds: supported_chain_id,
});

const bsc = new BscConnector({
  supportedChainIds: supported_chain_id, // later on 1 ethereum mainnet and 3 ethereum ropsten will be supported
});

const walletconnect = new WalletConnectConnector({
  rpcUrl: rpc_url,
  bridge: "https://bridge.walletconnect.org",
  qrcode: true,
  pollingInterval: POLLING_INTERVAL,
});

export const connectors = {
  injected: injected,
  walletConnect: walletconnect,
  bscwallet: bsc,
};

export const chainId = supported_chain_id;
