import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useWeb3React } from "@web3-react/core";
import { Web3Provider } from "@ethersproject/providers";
import { connectors } from "./connectors";
import { toHex, truncateAddress } from "./utils";
import { useEagerConnect, useInactiveListener } from "./hooks";

const Header = () => {
  const context = useWeb3React();
  const {
    connector,
    library,
    chainId,
    account,
    activate,
    deactivate,
    active,
    error,
  } = context;

  function getLibrary(provider) {
    const library = new Web3Provider(provider);
    library.pollingInterval = 8000;
    return library;
  }

  const [symbol, setSymbol] = useState("");
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState();

  const refreshState = () => {
    window.localStorage.setItem("provider", undefined);
  };

  const disconnect = () => {
    refreshState();
    deactivate();
  };

  const [ethBalance, setEthBalance] = useState();

  useEffect(() => {
    console.log(connector);
    if (account) {
      let sortAddress = account.substr(0, 8) + "...";
      setAddress(sortAddress);
    } else {
      setAddress(undefined);
      setEthBalance(undefined);
    }
  }, []);

  return (
    <>
      <header className="header">
        <div className="header__content">
          <div className="header__logo">
            <Link to={`${process.env.PUBLIC_URL}/`}>
              <img src={require("../assets/img/logo.png")} alt="" />
            </Link>
          </div>

          <form action="#" className="header__search">
            <input
              type="text"
              placeholder="Search items, collections, and creators"
            />
            <button type="button">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M21.71,20.29,18,16.61A9,9,0,1,0,16.61,18l3.68,3.68a1,1,0,0,0,1.42,0A1,1,0,0,0,21.71,20.29ZM11,18a7,7,0,1,1,7-7A7,7,0,0,1,11,18Z" />
              </svg>
            </button>
            <button type="button" className="close">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M13.41,12l6.3-6.29a1,1,0,1,0-1.42-1.42L12,10.59,5.71,4.29A1,1,0,0,0,4.29,5.71L10.59,12l-6.3,6.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l6.29,6.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z" />
              </svg>
            </button>
          </form>

          <div className="header__menu">
            <ul className="header__nav">
              <li className="header__nav-item">
                <a
                  className="header__nav-link"
                  href="#"
                  role="button"
                  id="dropdownMenuHome"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  Explore{" "}
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M17,9.17a1,1,0,0,0-1.41,0L12,12.71,8.46,9.17a1,1,0,0,0-1.41,0,1,1,0,0,0,0,1.42l4.24,4.24a1,1,0,0,0,1.42,0L17,10.59A1,1,0,0,0,17,9.17Z" />
                  </svg>
                </a>

                <ul
                  className="dropdown-menu header__nav-menu"
                  aria-labelledby="dropdownMenuHome"
                >
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      All NFTs
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Art
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Collectibles
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Domain Names
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Music
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Photography
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Sports
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Trading Cards
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Utility
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/explore-all`}>
                      Virtual Worlds
                    </Link>
                  </li>
                </ul>
              </li>
              <li className="header__nav-item">
                <a
                  className="header__nav-link"
                  href="#"
                  role="button"
                  id="dropdownMenu"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  Stats{" "}
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M17,9.17a1,1,0,0,0-1.41,0L12,12.71,8.46,9.17a1,1,0,0,0-1.41,0,1,1,0,0,0,0,1.42l4.24,4.24a1,1,0,0,0,1.42,0L17,10.59A1,1,0,0,0,17,9.17Z" />
                  </svg>
                </a>

                <ul
                  className="dropdown-menu header__nav-menu"
                  aria-labelledby="dropdownMenu"
                >
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/rankings`}>
                      Rankings
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/activity`}>
                      Activity
                    </Link>
                  </li>
                </ul>
              </li>

              <li className="header__nav-item">
                <a
                  className="header__nav-link"
                  href="#"
                  role="button"
                  id="dropdownMenu0"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  Resource Center{" "}
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M17,9.17a1,1,0,0,0-1.41,0L12,12.71,8.46,9.17a1,1,0,0,0-1.41,0,1,1,0,0,0,0,1.42l4.24,4.24a1,1,0,0,0,1.42,0L17,10.59A1,1,0,0,0,17,9.17Z" />
                  </svg>
                </a>

                <ul
                  className="dropdown-menu header__nav-menu"
                  aria-labelledby="dropdownMenu0"
                >
                  <li>
                    <a
                      href="https://hyperflair.medium.com/hyperflair-flair-white-paper-81c0a09f63bd"
                      target="_blank"
                    >
                      About
                    </a>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/faqs`}>FAQ</Link>
                  </li>
                  <li>
                    <a href="#">Hyperflair token</a>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/contact`}>
                      Contact
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/privacy`}>
                      Privacy Policy
                    </Link>
                  </li>
                </ul>
              </li>
            </ul>
          </div>

          <div className="header__actions">
            <div className="header__action header__action--search">
              <button className="header__action-btn" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                  <path d="M21.71,20.29,18,16.61A9,9,0,1,0,16.61,18l3.68,3.68a1,1,0,0,0,1.42,0A1,1,0,0,0,21.71,20.29ZM11,18a7,7,0,1,1,7-7A7,7,0,0,1,11,18Z" />
                </svg>
              </button>
            </div>
            {!active ? (
              <div className="header__action header__action--signin">
                <Link
                  to={`${process.env.PUBLIC_URL}/wallet`}
                  className="header__action-btn header__action-btn--signin"
                >
                  <span>Sign In</span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M20,12a1,1,0,0,0-1-1H11.41l2.3-2.29a1,1,0,1,0-1.42-1.42l-4,4a1,1,0,0,0-.21.33,1,1,0,0,0,0,.76,1,1,0,0,0,.21.33l4,4a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42L11.41,13H19A1,1,0,0,0,20,12ZM17,2H7A3,3,0,0,0,4,5V19a3,3,0,0,0,3,3H17a3,3,0,0,0,3-3V16a1,1,0,0,0-2,0v3a1,1,0,0,1-1,1H7a1,1,0,0,1-1-1V5A1,1,0,0,1,7,4H17a1,1,0,0,1,1,1V8a1,1,0,0,0,2,0V5A3,3,0,0,0,17,2Z"></path>
                  </svg>
                </Link>
              </div>
            ) : (
              <div className="header__action header__action--profile">
                <a
                  className="header__profile-btn header__profile-btn--verified"
                  href="#"
                  role="button"
                  id="dropdownMenuProfile"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <img
                    src={require("../assets/img/avatars/robots.jpg")}
                    alt=""
                  />
                  <div>
                    <p>{account.substr(0, 8) + "..."}</p>
                    <span>
                      {ethBalance} {symbol}
                    </span>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M17,9.17a1,1,0,0,0-1.41,0L12,12.71,8.46,9.17a1,1,0,0,0-1.41,0,1,1,0,0,0,0,1.42l4.24,4.24a1,1,0,0,0,1.42,0L17,10.59A1,1,0,0,0,17,9.17Z"></path>
                  </svg>
                </a>

                <ul
                  className="dropdown-menu header__profile-menu"
                  aria-labelledby="dropdownMenuProfile"
                >
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/account`}>
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        stroke="currentColor"
                        strokeWidth="2"
                        fill="none"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                        <circle cx="12" cy="7" r="4"></circle>
                      </svg>
                      <span>Profile</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/edit-profile`}>
                      <svg
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                        stroke="currentColor"
                        strokeWidth="2"
                        fill="none"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        k
                      >
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="8.5" cy="7" r="4"></circle>
                        <line x1="20" y1="8" x2="20" y2="14"></line>
                        <line x1="23" y1="11" x2="17" y2="11"></line>
                      </svg>
                      <span>Edit Profile</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/activity`}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                      >
                        <path d="M3.71,16.29a1,1,0,0,0-.33-.21,1,1,0,0,0-.76,0,1,1,0,0,0-.33.21,1,1,0,0,0-.21.33,1,1,0,0,0,.21,1.09,1.15,1.15,0,0,0,.33.21.94.94,0,0,0,.76,0,1.15,1.15,0,0,0,.33-.21,1,1,0,0,0,.21-1.09A1,1,0,0,0,3.71,16.29ZM7,8H21a1,1,0,0,0,0-2H7A1,1,0,0,0,7,8ZM3.71,11.29a1,1,0,0,0-1.09-.21,1.15,1.15,0,0,0-.33.21,1,1,0,0,0-.21.33.94.94,0,0,0,0,.76,1.15,1.15,0,0,0,.21.33,1.15,1.15,0,0,0,.33.21.94.94,0,0,0,.76,0,1.15,1.15,0,0,0,.33-.21,1.15,1.15,0,0,0,.21-.33.94.94,0,0,0,0-.76A1,1,0,0,0,3.71,11.29ZM21,11H7a1,1,0,0,0,0,2H21a1,1,0,0,0,0-2ZM3.71,6.29a1,1,0,0,0-.33-.21,1,1,0,0,0-1.09.21,1.15,1.15,0,0,0-.21.33.94.94,0,0,0,0,.76,1.15,1.15,0,0,0,.21.33,1.15,1.15,0,0,0,.33.21,1,1,0,0,0,1.09-.21,1.15,1.15,0,0,0,.21-.33.94.94,0,0,0,0-.76A1.15,1.15,0,0,0,3.71,6.29ZM21,16H7a1,1,0,0,0,0,2H21a1,1,0,0,0,0-2Z" />
                      </svg>
                      <span>Activity</span>
                    </Link>
                  </li>
                  <li>
                    <Link to={`${process.env.PUBLIC_URL}/create-item`}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                      >
                        <path d="M10,13H4a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1h6a1,1,0,0,0,1-1V14A1,1,0,0,0,10,13ZM9,19H5V15H9ZM20,3H14a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1h6a1,1,0,0,0,1-1V4A1,1,0,0,0,20,3ZM19,9H15V5h4Zm1,7H18V14a1,1,0,0,0-2,0v2H14a1,1,0,0,0,0,2h2v2a1,1,0,0,0,2,0V18h2a1,1,0,0,0,0-2ZM10,3H4A1,1,0,0,0,3,4v6a1,1,0,0,0,1,1h6a1,1,0,0,0,1-1V4A1,1,0,0,0,10,3ZM9,9H5V5H9Z" />
                      </svg>
                      <span>Create new item</span>
                    </Link>
                  </li>

                  <li>
                    <a href="javascript:void(0)" onClick={disconnect}>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                      >
                        <path d="M4,12a1,1,0,0,0,1,1h7.59l-2.3,2.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0l4-4a1,1,0,0,0,.21-.33,1,1,0,0,0,0-.76,1,1,0,0,0-.21-.33l-4-4a1,1,0,1,0-1.42,1.42L12.59,11H5A1,1,0,0,0,4,12ZM17,2H7A3,3,0,0,0,4,5V8A1,1,0,0,0,6,8V5A1,1,0,0,1,7,4H17a1,1,0,0,1,1,1V19a1,1,0,0,1-1,1H7a1,1,0,0,1-1-1V16a1,1,0,0,0-2,0v3a3,3,0,0,0,3,3H17a3,3,0,0,0,3-3V5A3,3,0,0,0,17,2Z" />
                      </svg>
                      <span>Sign out</span>
                    </a>
                  </li>
                </ul>
              </div>
            )}
          </div>

          <button className="header__btn" type="button">
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </header>
    </>
  );
};
export default Header;
