
import React, { useEffect } from "react";
import ImageUploading from "react-images-uploading";
import $ from 'jquery';

const CreateItem = () => {
    useEffect(() => {
        window.scrollTo(0, 0)
    }, []);
    // switch textarea hide & show
    $(function () {
        $("#switch-id").change(function () {
            if ($(this).is(":checked")) {
                $(".unlock-textarea").show();
            } else {
                $(".unlock-textarea").hide();
            }
        });
    });
    // switch textarea hide & show over

    const [images, setImages] = React.useState([]);

    const onChange = (imageList, addUpdateIndex) => {
        setImages(imageList);
    };


    return (
        <>
            <div className="container">
                <div className="row row--grid justify-content-center">
                    <div className="col-12 col-lg-9">
                        <div className="main__title main__title--left">
                            <h2>Create New Item</h2>
                        </div>
                        <form className="sign__form sign__form--create">
                            <p className="required-field"><span>*</span> Required fields</p>
                            <div className="sign__group">
                                <label className="sign__label required-field" htmlFor="itemname">Image, Video, Audio, or 3D Model<span className="ml-2">*</span></label>
                                <p className="f-12 f-500">File types supported: JPG, PNG, GIF, SVG, MP4, WEBM, MP3, WAV, OGG, GLB, GLTF. Max size: 100 MB</p>
                                <ImageUploading value={images} onChange={onChange} dataURLKey="data_url" name="image">
                                    {({
                                        imageList,
                                        onImageUpload,
                                        isDragging,
                                        dragProps
                                    }) => (
                                        <div className="upload__image-wrapper">
                                            <div style={isDragging ? { color: "red" } : null} onClick={onImageUpload}{...dragProps} className="upload-img-wrapper">
                                                Click or Drop here (max file size)
                                                {imageList.map((image, index) => (
                                                    <div key={index} className="image-item">
                                                        <img src={image.data_url} alt="" />
                                                    </div>
                                                ))}
                                                <button type="button" className="edit-profile-pic"><i className="fa-solid fa-pencil"></i></button>
                                            </div>
                                        </div>
                                    )}
                                </ImageUploading>

                            </div>
                            <div className='sign__group'>
                                <label className="sign__label required-field" htmlFor="itemname">Name<span className="ml-2">*</span></label>
                                <input type="text" name="itemname" className="sign__input" placeholder="Item Name" />
                            </div>
                            <div className='sign__group'>
                                <label className="sign__label required-field" htmlFor="eLinks">External link<span className="ml-2">*</span></label>
                                <p className='f-12 f-500'>Hyperflair will include a link to this URL on this item's detail page, so that users can click to learn more about it. You are welcome to link to your own webpage with more details.</p>
                                <input type="text" name="eLinks" className="sign__input" placeholder="https://yoursite.io" />
                            </div>
                            <div className='sign__group'>
                                <label className="sign__label required-field" htmlFor="description">Description</label>
                                <p className='f-12 f-500'>The description will be included on the item's detail page underneath its image. Markdown syntax is supported.</p>
                                <textarea id="description" name="description" className="sign__textarea" placeholder="Provide a detailed description of your item."></textarea>
                            </div>
                            <div className='asset--form'>
                                <div className='asset--content'>
                                    <i className="fa-solid fa-list"></i>
                                    <div className='asset--content--main'>
                                        <span className='asset--content--label'>Properties</span>
                                        <p className='asset--content--header'>Textual traits that show up as rectangles</p>
                                    </div>
                                </div>
                                <div className='asset--side'>
                                    <a href="#addpreoperModal" className='feature__icon feature__icon--green mt-0' data-toggle="modal" data-target="#addpreoperModal">
                                        <i className="fa-solid fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <div className='asset--form'>
                                <div className='asset--content'>
                                    <i className="fa-solid fa-star"></i>
                                    <div className='asset--content--main'>
                                        <span className='asset--content--label'>Levels</span>
                                        <p className='asset--content--header'>Numerical traits that show as a progress bar</p>
                                    </div>
                                </div>
                                <div className='asset--side'>
                                    <a href="#levelModal" className='feature__icon feature__icon--green mt-0' data-toggle="modal" data-target="#levelModal">
                                        <i className="fa-solid fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <div className='asset--form'>
                                <div className='asset--content'>
                                    <i className="fa-solid fa-chart-simple"></i>
                                    <div className='asset--content--main'>
                                        <span className='asset--content--label'>Stats</span>
                                        <p className='asset--content--header'>Numerical traits that just show as numbers</p>
                                    </div>
                                </div>
                                <div className='asset--side'>
                                    <a href="#statsModal" className='feature__icon feature__icon--green mt-0' data-toggle="modal" data-target="#statsModal">
                                        <i className="fa-solid fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <div className='w-100 unlock-switch'>
                                <div className='asset--form'>
                                    <div className='asset--content'>
                                        <i className="fa-solid fa-lock"></i>
                                        <div className='asset--content--main'>
                                            <span className='asset--content--label'>Unlockable Content</span>
                                            <p className='asset--content--header'>Include unlockable content that can only be revealed by the owner of the item.</p>
                                        </div>
                                    </div>
                                    <div className='asset--side'>
                                        <div className="custom-control custom-switch ">
                                            <input type="checkbox" className="custom-control-input" id="switch-id" />
                                            <label className="custom-control-label" htmlFor="switch-id"></label>
                                        </div>
                                    </div>
                                </div>
                                <div className='sign__group unlock-textarea mt-2 mb-0'>
                                    <textarea id="" name="unlockable-content" className="sign__textarea mb-0" placeholder="Enter content (access key, code to redeem, link to a file, etc.)"></textarea>
                                </div>
                            </div>
                            <div className='asset--form'>
                                <div className='asset--content'>
                                    <i className="fa-solid fa-triangle-exclamation"></i>
                                    <div className='asset--content--main'>
                                        <span className='asset--content--label'>Explicit & Sensitive Content</span>
                                        <p className='asset--content--header'>Set this item as explicit and sensitive content</p>
                                    </div>
                                </div>
                                <div className='asset--side'>
                                    <div className="custom-control custom-switch ">
                                        <input type="checkbox" className="custom-control-input" id="explicit" />
                                        <label className="custom-control-label" htmlFor="explicit"></label>
                                    </div>
                                </div>
                            </div>
                            <div className='sign__group mt-3'>
                                <label className="sign__label required-field" htmlFor="supplay">Supply</label>
                                <p className='f-12 f-500'>The number of items that can be minted. No gas cost to you! <a href="#supplyModal" data-toggle="modal" data-target="#supplyModal"><i className="fas fa-info-circle"></i></a></p>
                                <input type="text" name="supply" className="sign__input" defaultValue={1} disabled />
                            </div>


                            <div className="sign__group mt-3">
                                <label className="sign__label" htmlFor="Blockchain">Blockchain</label>
                                <div className="filter__group mt-2">
                                    <ul className="filter__checkboxes">
                                        <li>
                                            <input id="type5" type="checkbox" name="type5" defaultChecked="" />
                                            <label htmlFor="type5">
                                                <img src={require('../assets/img/bnb2.png')} className="w-25px" alt="BNB" />
                                                &nbsp;Binance Network Chain
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className='row w-100'>
                                <div className='col-sm-12 col-md-4 col-lg-3'>
                                    <button type="button" className="sign__btn">Create item</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            {/* Add Properties Modals */}
            <div className="modal fade" id="addpreoperModal" tabIndex="-1" aria-labelledby="addpreoperModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="font-weight-bold modal-title text-body" id="exampleModalLabel">Add Properties</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <p>Properties show up underneath your item, are clickable, and can be filtered in your collection's sidebar.</p>
                            <form action="sign__form sign__form--create">
                                <div className='row'>
                                    <div className="col">
                                        <div className="sign__group">
                                            <label className="sign__label" htmlFor="type">Type</label>
                                            <input type="text" className="sign__input" id="type" placeholder='Character' />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="sign__group">
                                            <label className="sign__label" htmlFor="name">Name</label>
                                            <input type="text" className="sign__input" id="name" placeholder='Name' />
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-4 col-lg-4">
                                        <button type="button" className="sign__btn m-0">Save changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {/* Add Leve Modals */}
            <div className="modal fade" id="levelModal" tabIndex="-1" aria-labelledby="levelModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="font-weight-bold modal-title text-body" id="levelModal">Add Levels</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <p>Levels show up underneath your item, are clickable, and can be filtered in your collection's sidebar.</p>
                            <form action="sign__form sign__form--create">
                                <div className='row'>
                                    <div className="col">
                                        <div className="sign__group">
                                            <label className="sign__label" htmlFor="name">Name</label>
                                            <input type="text" className="sign__input" id="name" placeholder='Name' />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="">
                                            <label className="sign__label" htmlFor="name">Value</label>
                                            <div className="input-group mb-3">
                                                <input type="number" className="form-control sign__input" placeholder="0" aria-label="Value" aria-describedby="basic-addon2" />
                                                <div className="input-group-append">
                                                    <span className="input-group-text" id="basic-addon2">of</span>
                                                </div>
                                                <input type="number" className="form-control sign__input" placeholder="0" aria-label="Value" aria-describedby="basic-addon2" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-4 col-lg-4">
                                        <button type="button" className="sign__btn m-0">Save changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {/* Add Stats Modals */}
            <div className="modal fade" id="statsModal" tabIndex="-1" aria-labelledby="statsModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="font-weight-bold modal-title text-body" id="statsModal">Add Stats</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <p>Stats show up underneath your item, are clickable, and can be filtered in your collection's sidebar.</p>
                            <form action="sign__form sign__form--create">
                                <div className='row'>
                                    <div className="col">
                                        <div className="sign__group">
                                            <label className="sign__label" htmlFor="name">Name</label>
                                            <input type="text" className="sign__input" id="name" placeholder='Name' />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="">
                                            <label className="sign__label" htmlFor="name">Value</label>
                                            <div className="input-group mb-3">
                                                <input type="number" className="form-control sign__input" placeholder="0" aria-label="Value" aria-describedby="basic-addon2" />
                                                <div className="input-group-append">
                                                    <span className="input-group-text" id="basic-addon2">of</span>
                                                </div>
                                                <input type="number" className="form-control sign__input" placeholder="0" aria-label="Value" aria-describedby="basic-addon2" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-4 col-lg-4">
                                        <button type="button" className="sign__btn m-0">Save changes</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            {/* Supplay Modal */}
            <div className="modal fade" id="supplyModal" tabIndex="-1" aria-labelledby="supplyModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="font-weight-bold modal-title text-body" id="supplyModal">How does token supply work?</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="accordion mt-0" id="accordionExample2">
                                <div className="card">
                                    <div className="card-head" id="headeOne">
                                        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapsOne" aria-expanded="false" aria-controls="collapsOne">
                                            01. What is minting?
                                        </h2>
                                    </div>
                                    <div id="collapsOne" className="collapse" aria-labelledby="headeOne" data-parent="#accordionExample2">
                                        <div className="card-body">
                                            <p>
                                                Minting is an action that brings an item into existence on the blockchain, and costs gas to do so. Minting using Hyperflair tools is lazy, meaning it only occurs when necessary:
                                                    <br />
                                                    <span className="pl-3 pt-2">1. When you transfer an item to another account</span>
                                                    <br />
                                                    <span className="pl-3 pb-2">2. When someone buys an item from you</span>
                                                    <br/>
                                                This means that you can create as much as you want here for free.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="card mt-2">
                                    <div className="card-head" id="headeTwo">
                                        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapsTwo" aria-expanded="false" aria-controls="collapsTwo">
                                            02. How are limits enforced?
                                        </h2>
                                    </div>
                                    <div id="collapsTwo" className="collapse" aria-labelledby="headeTwo" data-parent="#accordionExample2">
                                        <div className="card-body">
                                            <p>The maximum supply ("hard cap") of your NFT will be encoded in its ID. This allows the smart contract to check whether any more are allowed to be minted.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default CreateItem